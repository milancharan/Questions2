
create table Category(
    CategoryID int PRIMARY KEY,
    CategoryName varchar(25),
    ParentID int,
    FOREIGN KEY (ParentID) REFERENCES Category(CategoryID)
);

INSERT INTO Category VALUES
(1, 'Food', NULL),
(2, 'Electronics', NULL),
(3, 'Bevarages', 1),
(4, 'Breads', 1),
(5, 'BeakedGood', 1),
(6, 'Camera&Photos	', 2),
(7, 'Cars&VehicleElectronics', 2);

create table Brand(
    BrandID int PRIMARY KEY,
    BrandName varchar(25)
);

INSERT INTO Brand VALUES
(1, 'Iceberg'),
(2, 'Mojito'),
(3, 'Britania'),
(4, 'TGB'),
(5, 'Nessale'),
(6, 'Canon')

create table Image(
    ImageID int PRIMARY KEY,
    ImageName varchar(50),
    ImageURL varchar(200)
);

create table Product(
    ProductID int PRIMARY KEY,
    Name varchar(50),
    BrandID int,
    CategoryID int,
    Price int,
    Status varchar(25) DEFAULT 'inStock',
    CHECK(Status IN ('inStock','outofstock')),
    CreatedDate date
);

INSERT INTO Product VALUES
(1, 'BrownBread', 3, 4, 40, 'inStock', STR_TO_DATE('2021-01-02', '%y-%m-%i')),
(1, 'Irish Soda Bread', 3, 4, 50, 'inStock', STR_TO_DATE('2021-01-02', '%y-%m-%i')),
(1, 'Tea(T001)', 5, 3, 50, 'inStock', STR_TO_DATE('2021-01-02', '%y-%m-%i')),
(1, 'Cofee(T002)', 3, 4, 40, 'inStock', STR_TO_DATE('2021-01-02', '%y-%m-%i')),
(1, 'headphones', 3, 4, 40, 'inStock', STR_TO_DATE('2021-01-02', '%y-%m-%i')),
(1, 'Seatbelt', 3, 4, 40, 'inStock', STR_TO_DATE('2021-01-02', '%y-%m-%i')),
(1, 'SeatCover', 3, 4, 40, 'inStock', STR_TO_DATE('2021-01-02', '%y-%m-%i')),
(1, 'Camera-canon-1	', 3, 4, 40, 'inStock', STR_TO_DATE('2021-01-02', '%y-%m-%i')),

create table ProductDetail(
    ProductDetailID int PRIMARY KEY, 
    ProductID int,
    ImageID int,
    BrandID int,
    CategoryID int,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (ImageID) REFERENCES Image(ImageID),
    FOREIGN KEY (BrandID) REFERENCES Brand(BrandID),
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);



-- create table Category(
--     CategoryID int PRIMARY KEY,
--     CategoryName varchar(25),
--     ParentID int
-- );

-- ALTER TABLE Category
-- ADD CONSTRAINT fk_Category_cID
-- FOREIGN KEY (ParentID)
-- REFERENCES Category(CategoryID);



